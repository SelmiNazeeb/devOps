
ansible-playbook test_4_variables_playbook.yaml

ansible-playbook test_4_string_playbook.yaml

# Upgrade Jinja2
sudo pip install --upgrade Jinja2
ansible-playbook test_4_number_playbook.yaml