Compare 
	playbook-without-lookup.yaml 
	and 
	playbook-with-lookup
	
	