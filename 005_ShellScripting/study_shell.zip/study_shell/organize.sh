#!/bin/bash
#author : selmi
#Date: 26-05-2025

echo "enter directory"
read -r DIR_PATH

if [ ! -d $DIR_PATH ]; then
    echo " not exists"
    exit 1
fi

echo "enter extension"
read -r extension

mkdir -p $DIR_PATH/organization/$extension

for item in "$DIR_PATH"/*."$extension";
do
    mv "$item" "$DIR_PATH/organization/$extension"
done