#!/bin/bash
#author : selmi
#Date: 26-05-2025
#purpuse: print unique ip

msg=$1
subject=$(echo "$msg" | head -n1)
echo "${#subject}"
if [ ${#subject} -lt 60 ];
then
    echo "message was too short"
    exit 1
fi
