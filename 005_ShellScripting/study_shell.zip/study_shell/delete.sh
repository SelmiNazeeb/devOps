#!/bin/bash
#Author: Selmi

echo "enter directory"
read -r dir

echo "enter word"
read -r word

if [ ! -d $dir ];then
    echo "folder not exists"
    exit 1
fi

for file in "$dir"/*; 
do 
    sed -i "/$word/d" "$file"  # d for delete
done