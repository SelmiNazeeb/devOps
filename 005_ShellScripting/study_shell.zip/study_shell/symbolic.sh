#!/bin/bash
#Author: Selmi

echo "file"
read -r file

if [ -L $file ]; then
    echo "file is symbolic link"
    target=$(readlink -f $file)
    echo "$target"
elif [ -f $file ]; then
    echo "regular file"
else
    echo "file not found"
fi

