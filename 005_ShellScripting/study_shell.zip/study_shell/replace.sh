#!/bin/bash
#author : selmi
#Date: 26-05-2025
#Description:replace a word with another

echo "enter the file"
read -r file
echo "enter old word"
read -r old
echo "enter new word"
read -r new

sed -i "s/$old/$new/g" $file

