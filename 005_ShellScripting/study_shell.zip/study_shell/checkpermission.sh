#!/bin/bash
#author: Selmi
#Date: 26-05-2025
#Description:check permission

#set -x

for file in *;
do 
    if [ -r $file ] && [ -w $file ] && [ -x $file ];
    then
        echo $file
    fi
done