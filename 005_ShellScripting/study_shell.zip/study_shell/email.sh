#!/bin/bash
#author : selmi
#Date: 26-05-2025

EMAIL="selmisellu@gmail.com"
SUBJECT="High CPU OR Memory usage"

cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}')
memory_usage=$(free -h |grep 'Mem' | awk '{print $2')
memory_full=$(free -h |grep 'Mem' | awk '{print $6}')
memory_per=(($memory_full/$memory_usage)*100)
disk_usage=$(df -h)
date_time=$(date)

if [ "$cpu_usage" -gt '80' ] || [ "$memory_usage" -gt '80' ]; then
    echo "cpu usage is more"
    echo "cpu usage is more than 80%" | mail -s "$SUBJECT" "$EMAIL"
else
    echo "cpu usage is ok"
fi
