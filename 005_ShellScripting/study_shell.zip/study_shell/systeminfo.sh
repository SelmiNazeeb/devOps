#!/bin/bash
#Author: Selmi

LOG_DIR="./log"
mkdir -p "$LOG_DIR"
timestamp=$(date +"%Y%m&d_%H%M%S")
LOG_FILE="$LOG_DIR/systeminfo_$timestamp.log"

{
echo "system information"
echo "-----------------------"
echo "---date-----"
echo "$(date)"
echo "-----cpu usage------"
top -bn1 | grep "Cpu(s)" |awk '{print $2}'
echo "----disk usage------"
df -h
echo "-------memory usage--------"
free -h 
}  > "$LOG_FILE"