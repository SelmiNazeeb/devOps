#!/bin/bash
#author : selmi
#Date: 26-05-2025

current_hour = $(date +%H)

if [ "$current_hour" -ge 9 ] && [ "$current_hour" -lt 12 ]; then
    echo "good morning"
elif [ "$current_hour" -ge 12 ] && [ "$current_hour" -lt 16 ]; then
    echo "good afternoon"
elif [ "$current_hour" -ge 16 ] && [ "$current_hour" -lt 18 ]; then
    echo "good evening"
else
    echo "good night"
fi