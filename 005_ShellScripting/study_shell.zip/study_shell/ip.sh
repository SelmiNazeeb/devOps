#!/bin/bash
#author : selmi
#Date: 26-05-2025
#purpuse: print unique ip

echo "enter file"
read -r LOGFILE

# Check if the file exists
if [ ! -f "$LOGFILE" ]; then
  echo "Error: File '$LOGFILE' not found."
  exit 2
fi

# Extract and print unique IP addresses
# awk '{print $1}' "$LOGFILE" | sort | uniq
ip="^([0-9]{1,3}\.){3}[0-9]{1,3}$"

grep -oE "$ip" "$LOGFILE" | uniq
  




