#connected to insternet or not

if ping -c 1 example.com > /dev/null 2>&1; then
  echo "Connected to the internet."
else
  echo "No internet connection."
fi