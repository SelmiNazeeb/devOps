#!/bin/bash
#Author: Selmi

echo "enter word"
read -r word

echo "enter folder"
read -r folder

for file in "$folder"/*;
do
    count=$(grep -ic "$word" "$file")
    echo "$file contains $count" 
    total=$((total + count ))
done
echo "$total"