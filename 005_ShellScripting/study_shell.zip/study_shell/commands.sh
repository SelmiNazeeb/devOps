%H - hour
%M - minute
%S - second
%m - month
%A - day in week
%D - date
%Y -year
%p - AM, PM
%B - month

du -h "dir" | cut -f1       // display disk usage of dir and cut the first column
lshw -short     // harware info
string^^    // change string to uppercase  eg: echo "${word^^}"
grep -ic "word" "file"      // count of a word in a file
if [ -L filename ]      // symbolic link
file ->  -f,-e,-d,-s (file empty or not) , -L  
stat -c%s       // size of file
wc -l < "filename"      //count no of line a filename
find dir -type f -mtime +7 -exec rm -f {} \;    /// remove file created before 7 days
ps aux | awk '{print $2, $3}' | sort -nk2 | tail -n 1   (most cpu consumin process) 
find dir -type f -exec du -h {} + | sort -nk1 | tail -n 1  (most disk using file) 
cat /proc/net/dev | awk 'NR=2'  (network statics)

 wc -l  (count no of lines)
 wc -w  (count no of words)
 wc -m  (count no of characters)
 
list
-----
ls
ls -a   (hidden file)
ls -lh  (human readable)
ls -t   (sort file based modification time)
ls -r   (reverse order)
ls -R   (recursively list all directories,files and files inside the directory also)
ls -S   (sort based on size)
ls -d   (list directories)
ls -l   (list each file in each line)

echo
-----
echo "hello\nworld"
    hello\nworld

echo -e "hello\nworld" 
    hello
    world

cd 
pwd

cat (show content of file)
----------------------------
cat -n  (add number to line)
cat -s  (remove empty lines)
cat file1.txt file2.txt > combined.txt
cat file.txt | grep "shell"

cp
----
cp -r   (copy all files and directories recursivly)
cp -i   (ask confirmation)
cp -v   (verbos)

mv (for move file and rename file)

rm (remove)
-----------
rm -f 
rm -r
rm -i

grep
-----
grep -i     (ingore case diff)
grep -r     (recursively search)
grep -v     (non matching pattern)

awk
----
------file.txt------
    anu,1,tvm
    arun,2,klm
    henna,3,ekm
    -----------
awk '{print $1}' "file.txt"
    anu,1,tvm
    arun,2,klm
    henna,3,ekm
awk -F ',' '{print $2}' "file.txt"
    1
    2
    3

sed 
----
sed -i "s/old/new/g" "filename"  //replace a word with new word
sed -i "/word/d" "filename"      // delete a word from files

cut 
----
cut -f1 file.txt    (cut and print first column)
cut -d ',' -f1 file.txt     (seperator is ',' and print first column)
cut --compliment -f1 file.txt   (print column other than 1st)

sort
-----
sort file.txt   (sort in alaphabetical order)
sort -r         (sort in reverse order)
sort -n         (sort based on number)
sort -t ',' -k2,2 file.txt 
sort -t ',' -n -k2,2
sort -t ','  -k1,1 -n -k2,2

tail
----
tail -n 5 file.txt  (print last 5 lines)

head
----
head -n 5 file.txt  (print first 5 lines)
head file.txt   (print first 10 lines by default)

ps 
----
ps -ef  (show process , e - all process , f - detailed info)
ps -u   (u - user)
ps aux | grep <process_name>  (aux - runnning process)

top
----
top -p pid (specific process)
top -u      (username)


df -h  | awk 'NR==2'| awk '{print $5}'  ( 2nd row 5th column)
du -h filename  (disk usage by file)
kill pid
kill -9 (forceful deletion)
uptime

free    (memory usage)
-----
free -h     (human readable)
free -k     (kilobytes)
free -b     (bytes)
free -m     (megabyte)
free -g     (gegabyte)
free -t     (total)

ping -ic google.com (i- time interval,  c- no of requests)
wget
zip -r foldername.zip foldername
unzip filename -d filename%.zip


