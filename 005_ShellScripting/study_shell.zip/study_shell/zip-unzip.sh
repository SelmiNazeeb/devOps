#!/bin/bash
#author : selmi
#Date: 26-05-2025

echo "enter folder"
read -r folder
if [ -d $folder ]; then
   echo "folders exists"
   zip -r "$folder.zip" "$folder"
else
   echo "folder not exists"
fi

echo "enter file"
read -r file
if [ -f $file ]; then
    echo "file exits"
    unzip "$file" -d "${file%.zip}"
else
   echo "file not exists"
fi

