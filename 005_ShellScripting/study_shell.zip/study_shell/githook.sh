#!/bin/sh
# Read the commit message
msg=$(cat "$1")
# Get the first line (subject)
subject=$(echo "$msg" | head -n1)
echo "${#subject}"
# Check length
if [ ${#subject} -lt 60 ]; then
 echo "❌ Commit message too short! (Must be at least 60 characters)"
 echo "Your message was: \"$subject\""
 exit 1
 