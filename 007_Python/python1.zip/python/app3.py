import os
try:
    dir_path = "C:/Users/290419/Desktop/practice/python/ust1"
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    else:
        print("directory exist")
    with open(dir_path+"/hello.txt", "w") as f:
        f.write("hello world")
except Exception as e:
    print(e)