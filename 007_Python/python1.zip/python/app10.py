
with open("tmp/warning.txt",'r') as file:
    while True:
        chunks = file.read(10)
        if not chunks:
            break;
        print(chunks)


