import shutil
total,used,free = shutil.disk_usage('C:\\')
print("Total usage: %0.2f GB" %(total/(1024**3)))
print("used data: %0.2f GB" %(used/(1024**3)))
free_data = print("free data: %0.2f GB" %(free/(1024**3)))
if (free/(1024**3)) < 1:
    print("low disk space")