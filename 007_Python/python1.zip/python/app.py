
import json


def captureWarning(inputFile, outputFile):
    try:
        with open(inputFile, 'r') as file:
            content = file.read()
            #print(content)
            lines = content.split('\n')
            #print(lines[0])
            errors = []
            for line in lines:
                #line
                if line.__contains__('ERROR'):
                    logArr=line.split(" - ERROR - ")
                    errors.append({'time':logArr[0],'error_message':logArr[1]})
    except FileNotFoundError:
        print("file not found")

    except Exception as e:
        print(e)


    try:
        with open(outputFile, 'w') as file:
            json.dump(errors,file)
            #file.write(string(warning_lines))
    except:
        print("failed to create")

    #)

captureWarning("tmp/timestamp.log","tmp/error.json")

        