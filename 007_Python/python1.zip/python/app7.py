import json
with open("tmp/config.json",'r') as file:
    content = json.load(file)

# with open("tmp/python.py",'w') as file:
#     file.write(f"config= {content}")
    print(content)
    
