# name,age,city
# ansa,25,manjeri
# shameel,26,kondotty

import csv

input =[{'name': 'ansa', 'age': '25', 'city': 'manjeri'}, {'name': 'shameel', 'age': '26', 'city': 'kondotty'}]

# inputValues = [
#     ['name','age','city'],
#     ['asna','25','manjeri'],
#     ['shameel','26','kondotty']
# ]

with open("tmp/users.csv", 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(input[0].keys())
    for row in input:
        writer.writerow(row.values())
    

