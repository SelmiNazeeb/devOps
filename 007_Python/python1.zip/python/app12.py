import psutil
cpu_used = psutil.cpu_percent(interval=1)
print(f"current cpu usage: {cpu_used}%")
if(cpu_used > 80):
    print("high cpu utilization detected")
else:
    print("safe")