import json
with open("tmp/user_data.json",'r') as file:
    content=json.load(file)
    name_user=[]
    for object in content:
        if (object['age'] > "28"):
            name_user.append(object['name'])
    print(name_user)