import json
config_settings={
    "theme" : "dark",
    "language" : "react",
    "notification" : "enabled"
}

with open("tmp/config.json",'w') as file:
    json.dump(config_settings,file)
    