import os
dir_path = "tmp/my_data_folder"
if not os.path.exists(dir_path):
    os.makedirs(dir_path)
else:
    print("directory exists")

with open("tmp/my_data_folder/notes.txt",'w') as file:
    file.write("hello txt")
    