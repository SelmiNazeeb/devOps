from string import Template
with open("tmp/template_email.txt",'r') as file:
    content = file.read()

content = content.replace("{{", "${").replace("}}", "}")
    
data = {
    "name" : "admin",
    "status" : "Active",
    "link": "https://example.com/login"
    }
template = Template(content)
result=template.safe_substitute(data)
print(result)