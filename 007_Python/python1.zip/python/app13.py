import subprocess
with open("./servers.txt",'r') as file:
    content = file.read()
    list=[]
    list = content.split('\n')
    for server in list:
        try:
            if subprocess.run(["ping", server],stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True):
                print("ok it is pinging...")
        except subprocess.CalledProcessError:
            print("failed to ping")