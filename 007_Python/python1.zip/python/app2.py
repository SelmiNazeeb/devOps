try:
    with open("tmp/config.ini", 'r') as file:
        content = file.read()
        lines = content.split('\n')
        details = []
        for line in lines:
            if line.startswith('host'):
                details.append(line[7:])
            if (line.startswith('user')):
                details.append(line[7:])
    print(details[0])
    print(details[1])

except FileNotFoundError:
    print("File not found")
except Exception as e:
    print(e)
    


   