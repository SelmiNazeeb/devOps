import csv
with open("tmp/users.csv", 'r', newline="") as file:
    reader = csv.DictReader(file)
    list=[]
    for row in reader:
        list.append(row)
        print(row)